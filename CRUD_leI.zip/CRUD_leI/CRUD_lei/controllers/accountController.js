const account = require("../models/account");

exports.createAccount = async (req, res) => {
    console.log(req.body);
    //let data = await account.model.create({

   // })
}